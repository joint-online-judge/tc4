//
// Created by 黄抒扬 on 4/6/18.
//

#include <cmath>

bool filMod3(int a) {
    return (a % 3 == 0) ? true : false;
} //0

bool filSqrt(int a) {
    int temp = (int) sqrt((double)a);
    return (temp * temp == a) ? true : false;
} //1

bool filPrime(int a) {
    int lim = (int) sqrt((double)a);
    for (int i = 2; i <= lim; ++i)
        if (a % i == 0) return false;
    return true;
} //2

bool filLarger50(int a) {
    return (a > 50) ? true : false;
} //3

bool filSqLarger80(int a) {
    return (a * a > 50) ? true : false;
} //4

bool filRan7(int a) {
    return (a % 10 == 7) ? true : false;
} // 5

bool fil6Rand(int a) {
    int temp = a;
    while (temp >= 10)
        temp = temp / 10;
    return (temp == 6) ? true : false;
} // 6

//======================================================

int accReshape(int a, int b) {
    return ( a / 10 * 10 + b % 10);
} // 0

int accReadd(int a, int b) {
    return ( a % 10 + b);
} // 1

int accEvenOdd(int a, int b) {
    return (a % 2 * b + b);
} // 2

int accAverage(int a, int b) {
    return ( ( a + b ) / 2 );
}// 3

int accMixAver(int a, int b) {
    double aa = 1 / ((double) a);
    double bb = 1 / ((double) b);
    double cc = aa + bb;
    return (int)(1/cc);
} // 4

int accTempAver(int a, int b) {
    return (int)sqrt((double)(a*a) + (double)(b*b));
} // 5
