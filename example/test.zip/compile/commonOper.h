//
// Created by 黄抒扬 on 4/6/18.
//

#ifndef PROJ2_COMMONOPER_H
#define PROJ2_COMMONOPER_H

bool filMod3(int a); //0
bool filSqrt(int a); //1
bool filPrime(int a); //2
bool filLarger50(int a); //3
bool filSqLarger80(int a); //4
bool filRan7(int a); // 5
bool fil6Rand(int a); // 6

bool (*filOp[])(int) = {
        filMod3,
        filSqrt,
        filPrime,
        filLarger50,
        filSqLarger80,
        filRan7,
        fil6Rand
};

const int filNum = 7;


int accReshape(int a, int b); // 0
int accReadd(int a, int b); // 1
int accEvenOdd(int a, int b); // 2
int accAverage(int a, int b); // 3
int accMixAver(int a, int b); // 4
int accTempAver(int a, int b); // 5

int (*accOp[])(int, int) = {
        accReshape,
        accReadd,
        accEvenOdd,
        accAverage,
        accMixAver,
        accTempAver
};

const int accNum = 6;



#endif //PROJ2_COMMONOPER_H
